function turnoff ( n ) {
　　var s = document.getElementById( n ).style;
　　s.display = ( s.display == 'none' ) ? '' : 'none' ;
}
function turnoff1 ( m ) {
　　var j = document.getElementById( m ).style;
　　j.display = ( j.display == 'none' ) ? '' : 'none' ;
}
function turnoff2 ( o ) {
　　var p = document.getElementById( o ).style;
　　p.display = ( p.display == 'none' ) ? '' : 'none' ;
}